-- Run in Supabase SQL Editor before using the application.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 email text not null,
 full_name text,
 role text not null check (role in ('pharmacist','checker','warehouse_encoder','sales_supervisor','agent')),
 created_at timestamptz not null default now()
);
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(), product_name text not null, batch_number text not null,
 expiry_date date not null, received_date date not null default current_date, quantity integer not null check(quantity>=0),
 created_by uuid references auth.users(id), created_at timestamptz not null default now()
);
create table if not exists public.served_accounts (
 id uuid primary key default gen_random_uuid(), account_name text not null, product_name text not null,
 batch_number text not null, served_date date not null default current_date, quantity integer not null check(quantity>0),
 agent_name text not null, agent_email text, created_by uuid references auth.users(id), created_at timestamptz not null default now()
);
create table if not exists public.alerts (
 id uuid primary key default gen_random_uuid(), alert_type text not null check(alert_type in ('received','retrieval')),
 product_id uuid references public.products(id) on delete set null, served_id uuid references public.served_accounts(id) on delete set null,
 product_name text, account_name text, batch_number text, agent_email text, due_date date not null,
 resolved boolean not null default false, resolved_at timestamptz, resolved_by uuid references auth.users(id),
 last_emailed_at timestamptz, created_at timestamptz not null default now(), unique(alert_type,product_id,served_id)
);
create table if not exists public.app_settings (
 id integer primary key default 1 check(id=1), settings jsonb not null default '{"received_days":180,"served_days":180,"test_mode":false,"test_minutes":3,"emails":{"pharmacist":"","checker":"","encoder":"","supervisor":"","agents":["","","",""]}}'::jsonb,
 updated_at timestamptz not null default now()
);
insert into public.app_settings(id) values(1) on conflict(id) do nothing;

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.served_accounts enable row level security;
alter table public.alerts enable row level security;
alter table public.app_settings enable row level security;

-- Authenticated staff can read data. Pharmacists/checkers/encoders can create records.
create policy "profiles readable by authenticated" on public.profiles for select to authenticated using (true);
create policy "products readable by authenticated" on public.products for select to authenticated using (true);
create policy "products insert by stock staff" on public.products for insert to authenticated with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('pharmacist','checker','warehouse_encoder')));
create policy "products update by stock staff" on public.products for update to authenticated using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('pharmacist','checker','warehouse_encoder')));
create policy "served readable by authenticated" on public.served_accounts for select to authenticated using (true);
create policy "served insert by stock staff" on public.served_accounts for insert to authenticated with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('pharmacist','checker','warehouse_encoder')));
create policy "alerts readable by authenticated" on public.alerts for select to authenticated using (true);
create policy "alerts resolve by stock staff" on public.alerts for update to authenticated using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('pharmacist','checker','warehouse_encoder')));
create policy "settings readable by authenticated" on public.app_settings for select to authenticated using (true);
create policy "settings update by pharmacist" on public.app_settings for all to authenticated using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='pharmacist')) with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='pharmacist'));

-- IMPORTANT: after creating each user in Authentication, insert their matching profile.
-- Example (replace UUID/email/name):
-- insert into public.profiles(id,email,full_name,role) values ('AUTH-USER-UUID','pharmacist@company.com','Pharmacist Name','pharmacist');

-- If upgrading an existing database, also run:
-- alter table public.served_accounts add column if not exists agent_email text;
-- alter table public.alerts add column if not exists agent_email text;
