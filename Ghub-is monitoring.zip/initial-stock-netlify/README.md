# Initial Stock Monitoring System — Netlify + Supabase

A responsive web app for received stock, account service history, and recurring retrieval alerts. Built with React/Vite, Supabase Auth/Postgres, Netlify Functions, and Resend email delivery.

## Included
- Login for pharmacist, checker, warehouse encoder, sales supervisor, and agents (Supabase Auth).
- Received stock register: product, batch, expiry, received date, quantity.
- Account service register: account, product, batch, served date, quantity, agent.
- Editable received-stock and account-retrieval day windows (defaults to 180 days).
- Editable email recipients: pharmacist, checker, warehouse encoder, supervisor, and four sales agents.
- Alerts stay open until resolved; scheduled function re-sends due unresolved alerts each Friday.
- Test email button (pharmacist only) and test-mode setting.
- CSV export for stock and service records.
- Supabase URL/public anon key configurable from the login screen; never put a service-role key in the browser.

## Deploy to Netlify
1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. In Supabase Authentication, create each staff login. Then add one matching row to `public.profiles` for each auth user. The `id` must be the user's Auth UUID. Supported role values: `pharmacist`, `checker`, `warehouse_encoder`, `sales_supervisor`, `agent`.
4. Verify RLS is enabled. The schema includes starter policies for staff access; review them against your organization's security requirements before production use.
5. Create a Resend account, verify the sender domain/address, and create an API key.
6. Push this folder to a Git repository and import it into Netlify, or upload the built `dist` directory for the static frontend. For scheduled email functions, use Git-based Netlify deployment so functions are deployed too.
7. In Netlify → Site configuration → Environment variables, add:
   - `SUPABASE_URL` — Supabase project URL
   - `SUPABASE_SERVICE_ROLE_KEY` — service-role key (server-side only; never use in the frontend)
   - `RESEND_API_KEY` — Resend API key
   - `ALERT_FROM_EMAIL` — verified sender, e.g. `Initial Stock Monitor <alerts@yourdomain.com>`
   - `APP_BASE_URL` — deployed Netlify URL
8. Redeploy. Open the site, choose **Supabase connection settings**, enter the Supabase project URL and public anon/publishable key, then sign in.
9. As pharmacist, open Settings, set all recipient emails and alert windows, and save.

## Alert scheduling details
- `netlify/functions/alert-cron.mjs` runs every Friday at 09:00 UTC (17:00 Philippines time). Netlify scheduled functions require a supported Netlify plan/runtime and a Git-based deployment; confirm the schedule appears in Netlify after deployment.
- The scheduled function creates due alerts based on each row's received/served date and settings, then emails unresolved due alerts on each Friday run. Resolved alerts are not emailed again.
- Test mode changes the due-date threshold to immediate for the scheduled job; the **Run test alert** button sends a test email immediately. It does not create a real 3-minute scheduler. A minute-by-minute automated test would require an external scheduler or a separate scheduled test function. Turn test mode off after testing.
- Account retrieval alerts are sent to the pharmacist, checker, warehouse encoder, sales supervisor, and the specific agent email saved on the service record.

## Important implementation notes before production
- This starter stores the app's Supabase URL/public key in browser local storage. The public anon key is designed for browser use; data access relies on RLS.
- The included schema has an `agent_email` field on service records and alerts so retrieval notifications can be delivered to the assigned agent. If you already ran an older version of the schema, run the two ALTER TABLE statements at the bottom of `supabase/schema.sql`.
- For production, add audit logs, password reset UX, account deletion controls, stricter role-based write permissions, database backups, and review the schema/RLS with your administrator. Do not store patient data or sensitive clinical information in this system unless the deployment has been assessed and approved for that use.
